export const tiposError = [
    "valueMissing"
]

export const mensajes = {
    nombre: {
      valueMissing: "El campo nombre no puede estar vacío.",
    },
    precio: {
      valueMissing: "El campo precio no puede estar vacío.",
    },
    imagen: {
      valueMissing: "El campo imagen no puede estar vacío.",
    },
  };